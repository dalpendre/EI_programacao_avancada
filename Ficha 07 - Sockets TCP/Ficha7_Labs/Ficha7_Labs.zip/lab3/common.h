#ifndef _COMMON_H_
#define _COMMON_H_

#define ERR_ARGS 1
#define MAX_STR_NUM 20

#endif
