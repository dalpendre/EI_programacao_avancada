copie para esta diretoria APENAS os ficheiros:
 - server.c (Lab1)
 - client.c (Lab2)

nota 1: use o ficheiro "common.h" para definir constantes a usar nos dois programas.
nota 2: o makefile já está preparado para compilar os 2 programas.
